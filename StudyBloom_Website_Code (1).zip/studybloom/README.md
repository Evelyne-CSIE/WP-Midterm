# StudyBloom - Web Programming Midterm

StudyBloom is a four-page student study guide website created with HTML, CSS, and JavaScript only.

## Files

```text
studybloom/
  index.html       Home and the required 2x2 grid
  methods.html     Study methods + category filter
  resources.html   Educational resources, lists, table, internal/external links
  planner.html     Study session calculator + weekly schedule table
  style.css        All visual styles for the four pages
  script.js        Two JavaScript interactive features
  README.md        This file
```

## How to use it

1. Extract the ZIP file.
2. Open the `studybloom` folder in VS Code.
3. Open `index.html` in your browser.
4. Click Home, Study Methods, Resources, and Study Planner.
5. Try every Study Methods filter button: All Methods, Focus, Memory, Planning.
6. On Study Planner, click Calculate total. The default result is **115 minutes**.
   A row of Focus and Break cards will appear underneath.
7. Change the numbers, calculate again, and click Reset.

## What was taught in class?

- WP1-WP3: HTML document, headings, paragraphs, images, div containers.
- WP4: links, navigation, lists, hover.
- WP5: external CSS, layout, images, cards, table styling.
- WP6: HTML tables.
- WP7: variables, loops, calculation, `innerHTML`.
- WP8: `onclick`, `getElementById`, `getElementsByClassName`, and `style`.

The calculator also uses `Number(input.value)` to convert input text to numbers.
Its visual timeline uses the same loop and `innerHTML` string-building idea
as the multiplication table exercise in WP7/1.html. Both are worth understanding.

## Requirements checklist

- Four interconnected HTML pages
- Navigation menu on every page
- Meaningful headings and paragraphs
- 2x2 grid of four `div` elements on Home
- Images with descriptive `alt`
- HTML lists and tables
- Internal and external hyperlinks
- One external CSS file and consistent design
- Hover effects and layout styles
- Two different JavaScript features using DOM manipulation
- HTML, CSS, and JavaScript only

## Notes

Photos use online Unsplash image URLs. An internet connection is needed for them to load.
The suggested study methods are general educational ideas, not personalized professional advice.
Keep your Code Explanation Report's reflection in your own words and be ready to explain the functions.
